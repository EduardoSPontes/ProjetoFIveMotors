import React from "react";
import { View, Image, StyleSheet, Text, TouchableOpacity} from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createDrawerNavigator, DrawerContentScrollView, DrawerItemList } from "@react-navigation/drawer";
import { createNativeStackNavigator } from "@react-navigation/native-stack";

// Telas principais
import Home from "./screens/Home";
import QuemSomos from "./screens/QuemSomos";
import ProdutosServicos from "./screens/ProdutosServicos";
import Especificacao from "./screens/Especificacao";
import Contato from "./screens/Contato";

// Telas de Administração
import AdminHome from "./screens/AdminHome"; 
import VeiculoList from "./screens/VeiculoList";
import VeiculoCreate from "./screens/VeiculoCreate";
import EditVeiculo from "./screens/VeiculoEdit";
import DeleteVeiculo from "./screens/VeiculoDelete";
import MensagemList from "./screens/MensagemList";
import DetalhesMensagem from "./screens/MensagemDetalhes";

const Drawer = createDrawerNavigator();
const Stack = createNativeStackNavigator();

// Stack de Produtos
function ProdutosStack() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: "#0CDAC3" },
        headerTintColor: "#fff",
      }}
    >
      <Stack.Screen
        name="ProdutosServicos"
        component={ProdutosServicos}
        options={{ title: "Produtos e Serviços" }}
      />
      <Stack.Screen
        name="Especificacao"
        component={Especificacao}
        options={{ title: "Detalhes do Veículo" }}
      />
    </Stack.Navigator>
  );
}

// Stack da Administração
function AdminStack() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: "#0CDAC3" },
        headerTintColor: "#fff",
      }}
    >

      {/* 🔥 TELA INICIAL DO ADMIN */}
      <Stack.Screen
        name="AdminHome"
        component={AdminHome}
        options={{ title: "Administração" }}
      />

      {/* 🔹 VEÍCULOS */}
      <Stack.Screen
        name="VeiculoList"
        component={VeiculoList}
        options={{ title: "Veículos" }}
      />
      <Stack.Screen
        name="VeiculoCreate"
        component={VeiculoCreate}
        options={{ title: "Adicionar Veículo" }}
      />
      <Stack.Screen
        name="EditVeiculo"
        component={EditVeiculo}
        options={{ title: "Editar Veículo" }}
      />
      <Stack.Screen
        name="DeleteVeiculo"
        component={DeleteVeiculo}
        options={{ title: "Excluir Veículo" }}
      />

      {/* 🔹 MENSAGENS */}
      <Stack.Screen
        name="MensagemList"
        component={MensagemList}
        options={{ title: "Mensagens" }}
      />
      <Stack.Screen
        name="DetalhesMensagem"
        component={DetalhesMensagem}
        options={{ title: "Detalhes da Mensagem" }}
      />

    </Stack.Navigator>
  );
}

// Drawer customizado
function CustomDrawerContent(props) {
  return (
    <DrawerContentScrollView {...props}>
      <View style={styles.logoContainer}>
        <Image source={require("./assets/logo/Logo.png")} style={styles.logo} />
      </View>

      <View style={{ padding: 20 }}>
        
        {/* Botão Cadastrar-se */}
        <TouchableOpacity
          style={{
            borderWidth: 2,
            borderColor: "#0CDAC3",
            paddingVertical: 8,
            borderRadius: 8,
            marginBottom: 10
          }}
          onPress={() => props.navigation.navigate("Register")}
        >
          <Text style={{ textAlign: "center", color: "#0CDAC3", fontSize: 16 }}>
            Cadastrar-se
          </Text>
        </TouchableOpacity>

        {/* Botão Entrar */}
        <TouchableOpacity
          style={{
            backgroundColor: "#0CDAC3",
            paddingVertical: 8,
            borderRadius: 8,
          }}
          onPress={() => props.navigation.navigate("Login")}
        >
          <Text style={{ textAlign: "center", color: "#fff", fontSize: 16 }}>
            Entrar
          </Text>
        </TouchableOpacity>

      </View>
      <DrawerItemList {...props} />
    </DrawerContentScrollView>
  );
}

// APP
export default function App() {
  return (
    <NavigationContainer>
      <Drawer.Navigator
        drawerContent={(props) => <CustomDrawerContent {...props} />}
        screenOptions={{
          headerStyle: { backgroundColor: "#0CDAC3" },
          headerTintColor: "#fff",
          drawerActiveTintColor: "#0CDAC3",
          drawerLabelStyle: { fontWeight: "bold" },
        }}
      >
        <Drawer.Screen name="Home" component={Home} />
        <Drawer.Screen name="QuemSomos" component={QuemSomos} />
        <Drawer.Screen name="Produtos" component={ProdutosStack} />
        <Drawer.Screen name="Contato" component={Contato} />

        {/* 🔥 TUDO DA ADMINISTRAÇÃO AQUI */}
        <Drawer.Screen
          name="Administração"
          component={AdminStack}
          options={{ title: "Administração" }}
        />
      </Drawer.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  logoContainer: {
    alignItems: "center",
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: "#ddd",
    marginBottom: 10,
  },
  logo: {
    width: 120,
    height: 50,
    resizeMode: "contain",
  },
});
