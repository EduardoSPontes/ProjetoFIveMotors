import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  ScrollView,
  FlatList,
  StyleSheet,
  Alert,
  Dimensions,
} from "react-native";
import axios from "axios";

const { width } = Dimensions.get("window");

export default function Especificacao({ route, navigation }) {
  const { veiculoId } = route.params;

  const [veiculo, setVeiculo] = useState(null);
  const [mainImage, setMainImage] = useState(null);
  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    fetchVeiculo();
  }, []);

  const fetchVeiculo = async () => {
    try {
      const response = await axios.get(
        `http://localhost:5206/api/Veiculos/${veiculoId}`
      );
      setVeiculo(response.data);

      if (response.data.imagemsVeiculo?.length > 0) {
        setMainImage(response.data.imagemsVeiculo[0]);
      }
    } catch (error) {
      console.error("Erro ao carregar veículo:", error);
    }
  };

  // 🔥 Converter imagem URL para Base64 no lado do cliente
  const urlToBase64 = async (url) => {
    try {
      const response = await fetch(url);
      const blob = await response.blob();
      const reader = new FileReader();

      return await new Promise((resolve, reject) => {
        reader.onloadend = () => resolve(reader.result.split(",")[1]); // remove mime-type
        reader.onerror = reject;
        reader.readAsDataURL(blob);
      });
    } catch (err) {
      console.log("Erro ao converter imagem:", err);
      return null;
    }
  };

  // 🔥 Enviar interesse com anexos base64 (igual backend espera)
  const handleInteresse = async () => {
    if (!veiculo) return;

    try {
      // 1. Converter imagens
      const anexosBase64 = await Promise.all(
        veiculo.imagemsVeiculo.map(async (img) => await urlToBase64(img))
      );

      // 2. Montar mensagem igual backend
      const mensagem = `
📣 Registro de Interesse – FiveMotors

Veículo:
• Modelo: ${veiculo.marca} ${veiculo.modelo}
• Ano: ${veiculo.ano}
• Preço: R$ ${veiculo.preco.toFixed(0)}

Data do pedido: ${new Date().toLocaleString("pt-BR")}
      `;

      // 3. Payload igual backend
      const dados = {
        to: "ponteseduardo011@gmail.com",
        subject: `Interesse no veículo ${veiculo.marca} ${veiculo.modelo}`,
        message: mensagem,
        attachmentsBase64: anexosBase64,
      };

      console.log("🔵 Enviando payload:", dados);

      // 4. POST REAL
      await axios.post(
        "http://localhost:5206/api/Email/send",
        dados,
        { headers: { "Content-Type": "application/json" } }
      );

      Alert.alert("Sucesso", "Interesse enviado por e-mail!");
      setShowForm(false);

    } catch (error) {
      console.error("❌ Erro ao enviar interesse:", error.response || error);
      Alert.alert("Erro", "Não foi possível enviar o interesse.");
    }
  };

  // WhatsApp (continua igual)
 const handleWhatsApp = async () => {
  if (!veiculo) return;

  // 🔥 MENSAGEM 100% IGUAL AO BACKEND, APENAS REMOVIDO O BLOCO DO CLIENTE
  const mensagem =
    `Olá! Estou entrando em contato para solicitar informações detalhadas sobre o veículo abaixo:\n\n` +

    `📌 *Veículo:* ${veiculo.marca} ${veiculo.modelo}\n` +
    `📆 *Ano:* ${veiculo.ano}\n` +
    `💰 *Preço:* R$ ${veiculo.preco}\n\n` +
    `📝 *Descrição:* ${veiculo.descricao}\n\n` +

    `📸 *Imagens do veículo:*\n` +
    veiculo.imagemsVeiculo.map((img) => `• ${img}`).join("\n") +
    "\n\n" +

    "Para prosseguir, poderia me informar, por gentileza:\n\n" +
    "1️⃣ O valor final do veículo e possíveis condições de negociação?\n" +
    "2️⃣ Opções de pagamento e financiamento disponíveis?\n" +
    "3️⃣ Disponibilidade atual do modelo para visita ou test-drive?\n" +
    "4️⃣ Se há garantia e qual sua duração?\n\n" +
    "Aguardo o retorno. Obrigado!";

  try {
    await axios.post(
      "http://localhost:5206/api/WhatsApp/Enviar",
      {
        NumeroDestino: "5514998229788",
        Mensagem: mensagem,
      },
      {
        headers: {
          "Content-Type": "application/json"
        }
      }
    );

    Alert.alert("Sucesso", "Mensagem enviada via WhatsApp!");
  } catch (error) {
    console.error("❌ Erro WhatsApp:", error.response || error);
    Alert.alert("Erro", "Não foi possível enviar a mensagem.");
  }
};

  if (!veiculo) return <Text>Carregando...</Text>;

  const acessorios = [
    "Ar-condicionado digital",
    "Direção elétrica",
    "Central multimídia touchscreen",
    "Rodas de liga leve",
    "Controle de estabilidade",
    "Sensor de estacionamento",
    "Câmera de ré",
    "Banco em couro",
    "Airbags frontais e laterais",
    "Freios ABS",
  ];

  return (
    <ScrollView style={styles.container}>
      {/* GALERIA */}
      <View style={styles.galeria}>
        {mainImage && (
          <Image source={{ uri: mainImage }} style={styles.mainImage} />
        )}

        <FlatList
          data={veiculo.imagemsVeiculo}
          horizontal
          showsHorizontalScrollIndicator={false}
          keyExtractor={(item) => item}
          renderItem={({ item }) => (
            <TouchableOpacity onPress={() => setMainImage(item)}>
              <Image source={{ uri: item }} style={styles.thumbnail} />
            </TouchableOpacity>
          )}
          style={{ marginTop: 10 }}
        />
      </View>

      {/* DETALHES */}
      <View style={styles.detalhes}>
        <Text style={styles.titulo}>
          {veiculo.marca} {veiculo.modelo}
        </Text>
        <Text style={styles.subtitulo}>
          {veiculo.ano} • {veiculo.marca}
        </Text>
        <Text style={styles.preco}>R$ {veiculo.preco.toFixed(0)}</Text>

        <View style={styles.detalhesGrid}>
          <Text>Modelo: {veiculo.modelo}</Text>
          <Text>Ano: {veiculo.ano}</Text>
          <Text>Cor: Preto</Text>
          <Text>Combustível: Gasolina</Text>
          <Text>Transmissão: Automática</Text>
          <Text>Estoque: {veiculo.estoque} unidade(s)</Text>
        </View>

        {/* BOTÕES */}
        <View style={styles.botoes}>
          <TouchableOpacity
            style={styles.btnVoltar}
            onPress={() => navigation.goBack()}
          >
            <Text style={styles.btnText}>Voltar</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.btnInteresse}
            onPress={() => setShowForm(!showForm)}
          >
            <Text style={styles.btnText}>Tenho Interesse</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.btnWhats} onPress={handleWhatsApp}>
            <Text style={styles.btnText}>WhatsApp</Text>
          </TouchableOpacity>
        </View>

        {/* FORMULÁRIO */}
        {showForm && (
          <View style={styles.formulario}>
            <Text style={{ marginBottom: 10 }}>
              Confirmar interesse no veículo:
            </Text>

            <TouchableOpacity style={styles.btnConfirm} onPress={handleInteresse}>
              <Text style={styles.btnText}>Enviar Interesse</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>

      {/* ACESSÓRIOS */}
      <View style={styles.acessorios}>
        <Text style={styles.acessoriosTitle}>Acessórios e Itens de Série</Text>
        <View style={styles.listaAcessorios}>
          {acessorios.map((item) => (
            <Text key={item} style={styles.itemAcessorio}>
              ✔ {item}
            </Text>
          ))}
        </View>
      </View>
    </ScrollView>
  );
}

// ESTILOS
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#f2f3f5", padding: 10 },
  galeria: { marginBottom: 20 },
  mainImage: {
    width: "100%",
    height: 250,
    borderRadius: 14,
    resizeMode: "cover",
  },
  thumbnail: {
    width: 80,
    height: 60,
    marginRight: 10,
    borderRadius: 6,
    opacity: 0.8,
  },
  detalhes: {
    backgroundColor: "#fff",
    padding: 20,
    borderRadius: 16,
    marginBottom: 20,
  },
  titulo: { fontSize: 24, fontWeight: "700", marginBottom: 5 },
  subtitulo: { fontSize: 14, color: "#777", marginBottom: 10 },
  preco: { fontSize: 22, fontWeight: "700", color: "#b48d12", marginBottom: 15 },
  detalhesGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
    marginBottom: 15,
  },
  botoes: { flexDirection: "row", flexWrap: "wrap", gap: 10, marginBottom: 15 },
  btnVoltar: {
    backgroundColor: "#ececec",
    padding: 12,
    borderRadius: 8,
    marginRight: 10,
  },
  btnInteresse: {
    backgroundColor: "#1976d2",
    padding: 12,
    borderRadius: 8,
    marginRight: 10,
  },
  btnWhats: {
    backgroundColor: "#25d366",
    padding: 12,
    borderRadius: 8,
  },
  btnText: { color: "#fff", fontWeight: "600" },
  formulario: {
    backgroundColor: "#fafafa",
    padding: 15,
    borderRadius: 12,
    marginTop: 10,
  },
  btnConfirm: {
    backgroundColor: "#1976d2",
    padding: 10,
    borderRadius: 8,
    alignItems: "center",
  },
  acessorios: {
    backgroundColor: "#fff",
    padding: 15,
    borderRadius: 16,
    marginBottom: 20,
  },
  acessoriosTitle: { fontSize: 18, fontWeight: "600", marginBottom: 10 },
  listaAcessorios: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  itemAcessorio: {
    width: (width - 60) / 2,
    marginBottom: 5,
    fontSize: 14,
  },
});
