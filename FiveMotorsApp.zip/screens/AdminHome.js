import React from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";

export default function AdminHome({ navigation }) {
  return (
    <View style={styles.container}>
      <TouchableOpacity
        style={styles.button}
        onPress={() => navigation.navigate("VeiculoList")}
      >
        <Text style={styles.buttonText}>Gerenciar Veículos</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.button}
        onPress={() => navigation.navigate("MensagemList")}
      >
        <Text style={styles.buttonText}>Gerenciar Mensagens</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    padding: 20,
  },
  button: {
    backgroundColor: "#0CDAC3",
    padding: 20,
    borderRadius: 12,
    marginBottom: 20,
  },
  buttonText: {
    color: "#fff",
    fontSize: 18,
    textAlign: "center",
    fontWeight: "bold",
  },
});
