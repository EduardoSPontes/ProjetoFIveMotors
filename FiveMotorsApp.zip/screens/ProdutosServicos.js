import React, { useEffect, useState, useRef } from "react";
import {
  View,
  Text,
  FlatList,
  Image,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Animated,
  Dimensions,
} from "react-native";
import axios from "axios";

const { width } = Dimensions.get("window");

// Componente do Card do Carro
const CarCard = ({ item, navigation }) => {
  const scale = useRef(new Animated.Value(1)).current;
  const [showFront, setShowFront] = useState(true);

  const onPressIn = () =>
    Animated.spring(scale, { toValue: 1.05, useNativeDriver: true }).start();
  const onPressOut = () =>
    Animated.spring(scale, { toValue: 1, useNativeDriver: true }).start();
  const toggleImage = () => setShowFront(!showFront);

  const imagens = item.imagemsVeiculo || [];
  const imagemFrente = imagens[1] || imagens[0] || "https://via.placeholder.com/400x200";
  const imagemLateral = imagens[0] || "https://via.placeholder.com/400x200";

  return (
    <TouchableOpacity
      activeOpacity={1}
      onPressIn={onPressIn}
      onPressOut={onPressOut}
      onPress={toggleImage}
    >
      <Animated.View style={[styles.carCard, { transform: [{ scale }] }]}>
        <Image
          source={{ uri: showFront ? imagemLateral : imagemFrente }}
          style={styles.carImg}
        />
        <View style={styles.carInfo}>
          <Text style={styles.carTitle}>
            {item.marca} {item.modelo} ({item.ano})
          </Text>
          <Text style={styles.carDesc}>{item.descricao}</Text>
          <Text style={styles.carPrice}>
            R$ {item.preco ? item.preco.toFixed(2) : "0.00"}
          </Text>
          <TouchableOpacity
            style={styles.btnDetalhes}
            onPress={() => navigation.navigate("Especificacao", { veiculoId: item.veiculosId })}
          >
            <Text style={styles.btnText}>Ver Detalhes</Text>
          </TouchableOpacity>
        </View>
      </Animated.View>
    </TouchableOpacity>
  );
};

// Componente do Formulário de Filtros
const FilterForm = ({ onBuscar, veiculos }) => {
  const [modelo, setModelo] = useState("");
  const [marca, setMarca] = useState("");
  const [ano, setAno] = useState("");
  const [faixaPreco, setFaixaPreco] = useState("");
  const [open, setOpen] = useState(true);

  const marcasDisponiveis = [...new Set(veiculos.map((v) => v.marca))];
  const anosDisponiveis = [...new Set(veiculos.map((v) => v.ano))];

  const renderDropdown = (label, selectedValue, setSelectedValue, options) => (
    <View style={{ marginBottom: 10 }}>
      <Text style={styles.dropdownLabel}>{label}</Text>
      <TouchableOpacity
        style={styles.dropdownHeader}
        onPress={() => setSelectedValue(selectedValue ? "" : selectedValue)}
      >
        <Text style={{ color: selectedValue ? "#000" : "#6c757d" }}>
          {selectedValue || `Selecione ${label}`}
        </Text>
      </TouchableOpacity>
      {selectedValue &&
        options.map((opt, idx) => (
          <TouchableOpacity key={idx} style={styles.dropdownItem} onPress={() => setSelectedValue(opt.toString())}>
            <Text>{opt}</Text>
          </TouchableOpacity>
        ))}
    </View>
  );

  return (
    <View style={styles.filtersContainer}>
      <TouchableOpacity style={styles.toggleButton} onPress={() => setOpen(!open)}>
        <Text style={styles.toggleText}>{open ? "Esconder Filtros ▲" : "Mostrar Filtros ▼"}</Text>
      </TouchableOpacity>

      {open && (
        <View style={styles.filtersCard}>
          <TextInput
            placeholder="Modelo"
            style={styles.input}
            value={modelo}
            onChangeText={setModelo}
          />
          {renderDropdown("Marca", marca, setMarca, marcasDisponiveis)}
          {renderDropdown("Ano", ano, setAno, anosDisponiveis)}
          {renderDropdown("Faixa de Preço", faixaPreco, setFaixaPreco, ["Até 50.000", "50.000 – 100.000", "Acima de 100.000"])}

          <TouchableOpacity style={styles.btnBuscar} onPress={() => onBuscar({ modelo, marca, ano, faixaPreco })}>
            <Text style={styles.btnText}>Procurar</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
};

// Tela principal
export default function ProdutosServicos({ navigation }) {
  const [veiculos, setVeiculos] = useState([]);

  const fetchVeiculos = async (filters = {}) => {
    try {
      const response = await axios.get("http://localhost:5206/api/Veiculos");
      let data = response.data || [];

      // filtros
      if (filters.modelo) data = data.filter((v) => v.modelo?.toLowerCase().includes(filters.modelo.toLowerCase()));
      if (filters.marca) data = data.filter((v) => v.marca === filters.marca);
      if (filters.ano) data = data.filter((v) => v.ano === parseInt(filters.ano));
      if (filters.faixaPreco) {
        data = data.filter((v) => {
          if (filters.faixaPreco === "Até 50.000") return v.preco <= 50000;
          if (filters.faixaPreco === "50.000 – 100.000") return v.preco > 50000 && v.preco <= 100000;
          if (filters.faixaPreco === "Acima de 100.000") return v.preco > 100000;
          return true;
        });
      }

      setVeiculos(data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchVeiculos();
  }, []);

  return (
    <ScrollView style={styles.container}>
      <FilterForm onBuscar={fetchVeiculos} veiculos={veiculos} />

      <FlatList
        data={veiculos}
        keyExtractor={(item, index) => item?.VeiculosId?.toString() ?? index.toString()}
        renderItem={({ item }) => <CarCard item={item} navigation={navigation} />}
        contentContainerStyle={{ padding: 10 }}
      />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#F4F6F8" },
  filtersContainer: { margin: 10 },
  toggleButton: {
    backgroundColor: "#0E7C7B",
    padding: 12,
    borderRadius: 25,
    alignItems: "center",
    marginBottom: 10,
  },
  toggleText: { color: "#fff", fontWeight: "600" },
  filtersCard: {
    backgroundColor: "#fff",
    borderRadius: 16,
    padding: 15,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 3,
  },
  input: {
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 8,
    padding: 10,
    marginBottom: 10,
    backgroundColor: "#fff",
  },
  btnBuscar: {
    backgroundColor: "#0CDAC3",
    padding: 12,
    borderRadius: 25,
    alignItems: "center",
    marginTop: 5,
  },
  btnText: { color: "#fff", fontWeight: "600" },
  dropdownLabel: { color: "#6c757d", fontSize: 12, marginBottom: 4, textTransform: "uppercase" },
  dropdownHeader: { borderWidth: 1, borderColor: "#ccc", borderRadius: 8, padding: 10, backgroundColor: "#fff" },
  dropdownItem: { padding: 10, borderBottomWidth: 1, borderBottomColor: "#eee" },
  carCard: {
    backgroundColor: "#fff",
    borderRadius: 16,
    marginBottom: 15,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 3,
    alignItems: "center",
  },
  carImg: { width: width * 0.8, height: 220, borderRadius: 14 },
  carInfo: { padding: 10, alignItems: "center" },
  carTitle: { fontWeight: "bold", fontSize: 16, marginTop: 10, color: "#2B3A4B" },
  carDesc: { color: "#6C757D", fontSize: 14, marginVertical: 5 },
  carPrice: { fontWeight: "bold", fontSize: 16, color: "#7C6868" },
  btnDetalhes: { backgroundColor: "#0E7C7B", paddingVertical: 8, borderRadius: 20, alignItems: "center", marginTop: 10, paddingHorizontal: 20 },
});
