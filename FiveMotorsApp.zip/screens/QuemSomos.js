import React from "react";
import {
  View,
  Text,
  ScrollView,
  Image,
  ImageBackground,
  StyleSheet,
  Dimensions,
} from "react-native";

const { width } = Dimensions.get("window");

export default function QuemSomos() {
  return (
    <ScrollView style={styles.container}>
      {/* HERO */}
      <ImageBackground
        source={require("../assets/quemsomos/QuemSomos01.jpg")}
        style={styles.heroBg}
        imageStyle={{ opacity: 0.6 }}
      >
        <View style={styles.heroTitle}>
          <Text style={styles.heroTitleText}>
            Bem-vindo(a) à era FiveMotors!
          </Text>
          <Text style={styles.heroSubtitle}>
            Inovando o mercado automotivo com tecnologia, confiança e paixão por
            carros.
          </Text>
        </View>

        <View style={styles.heroDescription}>
          <View style={styles.descBox}>
            <Text style={styles.descText}>
              A <Text style={{ fontWeight: "bold" }}>FiveMotors</Text> é
              especialista em compra e venda de veículos, unindo qualidade,
              transparência e confiança em cada negociação.
            </Text>
          </View>

          <View style={styles.descBox}>
            <Text style={styles.descText}>
              Nossa equipe é movida pela paixão por carros e compromisso com o
              cliente — entregando segurança, inovação e excelência em cada
              serviço.
            </Text>
          </View>
        </View>
      </ImageBackground>

      {/* MISSÃO / VISÃO / VALORES */}
      <View style={styles.sectionLight}>
        <Text style={styles.sectionTitle}>Nossa Essência</Text>
        <View style={styles.cardsRow}>
          <View style={styles.mvvCard}>
            <Text style={styles.mvvTitle}>Missão</Text>
            <Text style={styles.mvvText}>
              Oferecer veículos de excelência e serviços que inspirem confiança
              e satisfação total.
            </Text>
          </View>
          <View style={styles.mvvCard}>
            <Text style={styles.mvvTitle}>Visão</Text>
            <Text style={styles.mvvText}>
              Ser referência nacional em inovação e atendimento automotivo de
              alta performance.
            </Text>
          </View>
          <View style={styles.mvvCard}>
            <Text style={styles.mvvTitle}>Valores</Text>
            <Text style={styles.mvvText}>
              Ética, transparência, respeito e paixão por carros — os pilares
              que impulsionam a FiveMotors.
            </Text>
          </View>
        </View>
      </View>

      {/* ESTRUTURA */}
      <View style={styles.sectionWhite}>
        <Text style={styles.sectionTitle}>Nossa Estrutura</Text>
        <Text style={styles.sectionText}>
          Uma concessionária moderna, com tecnologia de ponta, espaço confortável
          e um showroom que valoriza cada detalhe dos veículos.
        </Text>
        <Image
          source={require("../assets/quemsomos/concessionaria.jpg")}
          style={styles.estruturaImg}
        />
      </View>

      {/* EQUIPE */}
      <View style={styles.sectionLight}>
        <Text style={styles.sectionTitle}>Nossa Equipe</Text>
        <View style={styles.equipeRow}>
          <View style={styles.equipeCard}>
            <Image
              source={require("../assets/Grupo/Eduardo.jpg")}
              style={[styles.equipeImg
              ]}
            />
            <Text style={styles.equipeNome}>Eduardo</Text>
            <Text style={styles.cargo}>Programador Full-stack</Text>
          </View>

          <View style={styles.equipeCard}>
            <Image
             source={require("../assets/Grupo/Rayssa.jpg")}
              style={styles.equipeImg}
            />
            <Text style={styles.equipeNome}>Rayssa</Text>
            <Text style={styles.cargo}>Programadora Mobile</Text>
          </View>

          <View style={styles.equipeCard}>
            <Image
             source={require("../assets/Grupo/Larissa.jpg")}
              style={styles.equipeImg}
            />
            <Text style={styles.equipeNome}>Larissa</Text>
            <Text style={styles.cargo}>Design e UI/UX</Text>
          </View>

          <View style={styles.equipeCard}>
            <Image
             source={require("../assets/Grupo/Sabrina.jpg")}
              style={styles.equipeImg}
            />
            <Text style={styles.equipeNome}>Sabrina</Text>
            <Text style={styles.cargo}>Programadora Mobile</Text>
          </View>

           <View style={styles.equipeCard}>
            <Image
             source={require("../assets/Grupo/Gabi.jpg")}
              style={styles.equipeImg}
            />
            <Text style={styles.equipeNome}>Gabi</Text>
            <Text style={styles.cargo}>Design e UI/UX</Text>
          </View>
        </View>
      </View>

       {/* Footer */}
              <View style={styles.footer}>
                <View style={{ alignItems: "center", marginBottom: 15 }}>
                  <Image source={require("../assets/logo/Logo.png")} style={{ width: 120, height: 40, marginBottom: 5, tintColor: "#fff" }} />
                  <Text style={styles.footerText}>FiveMotors © 2025</Text>
                  <Text style={styles.footerText}>Todos os direitos reservados.</Text>
                </View>
                <View style={{ alignItems: "center" }}>
                  <Text style={styles.footerText}>Av. Automotiva, 500 - São Paulo, SP</Text>
                  <Text style={styles.footerText}>contato@fivemotors.com</Text>
                </View>
                <Text style={[styles.footerText, { marginTop: 10, fontSize: 12 }]}>
                  Desenvolvido por FiveMotors Dev Team
                </Text>
              </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#fff" },
  heroBg: { width: "100%", height: 500, justifyContent: "center" },
  heroTitle: { alignItems: "center", marginBottom: 20 },
  heroTitleText: {
    color: "#fff",
    fontSize: 28,
    fontWeight: "700",
    textAlign: "center",
    textShadowColor: "rgba(0,0,0,0.7)",
    textShadowOffset: { width: 3, height: 3 },
    textShadowRadius: 6,
  },
  heroSubtitle: {
    color: "#fff",
    fontSize: 16,
    textAlign: "center",
    textShadowColor: "rgba(0,0,0,0.6)",
    textShadowOffset: { width: 2, height: 2 },
    textShadowRadius: 4,
    marginTop: 5,
    maxWidth: width - 40,
  },
  heroDescription: {
    flexDirection: "row",
    justifyContent: "center",
    flexWrap: "wrap",
    gap: 20,
    paddingHorizontal: 10,
  },
  descBox: {
    width: "45%",
    minWidth: 140,
    marginVertical: 10,
  },
  descText: { color: "#fff", fontSize: 14, textAlign: "center" },

  sectionLight: { paddingVertical: 60, paddingHorizontal: 20, backgroundColor: "#F4F6F8" },
  sectionWhite: { paddingVertical: 60, paddingHorizontal: 20, backgroundColor: "#fff" },
  sectionTitle: { fontSize: 24, fontWeight: "700", color: "#1C2C3A", marginBottom: 30, textAlign: "center" },
  sectionText: { fontSize: 16, color: "#555", textAlign: "center", marginBottom: 20 },

  cardsRow: { flexDirection: "row", justifyContent: "center", flexWrap: "wrap", gap: 20 },
  mvvCard: {
    flex: 1,
    minWidth: 150,
    maxWidth: 220,
    backgroundColor: "#fff",
    borderRadius: 12,
    padding: 20,
    borderTopWidth: 4,
    borderTopColor: "#0E7C7B",
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
    margin: 10,
  },
  mvvTitle: { fontSize: 16, fontWeight: "700", color: "#0E7C7B", marginBottom: 8 },
  mvvText: { fontSize: 14, color: "#333" },

  footer: { backgroundColor: "#1f2a36", paddingVertical: 20, paddingHorizontal: 15 },
  footerText: { color: "#d1d1d1", textAlign: "center" },

  estruturaImg: { width: "100%", height: 200, borderRadius: 14, marginTop: 15, resizeMode: "cover" },

  equipeRow: { flexDirection: "row", flexWrap: "wrap", justifyContent: "center", gap: 20 },
  equipeCard: { alignItems: "center", width: 120, marginVertical: 10 },
  equipeImg: { width: 100, height: 100, borderRadius: 50 },
  equipeNome: { marginTop: 8, fontWeight: "700", color: "#1C2C3A", textAlign: "center" },
  cargo: { color: "#0E7C7B", fontWeight: "600", textAlign: "center" },
});
