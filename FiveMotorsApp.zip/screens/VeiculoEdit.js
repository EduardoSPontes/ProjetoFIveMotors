import React, { useEffect, useState } from "react";
import { View, Text, TextInput, ScrollView, TouchableOpacity, Alert } from "react-native";
import API from "../api/api";

export default function VeiculoEdit({ route, navigation }) {
  const { id } = route.params;
  const [form, setForm] = useState(null);

  useEffect(() => {
    API.get(`Veiculos/${id}`).then((res) => setForm(res.data));
  }, []);

  if (!form) return null;

  function handle(field, value) {
    setForm({ ...form, [field]: value });
  }

  async function salvar() {
    try {
      await API.put(`Veiculos/${id}`, form);
      Alert.alert("Alterado", "Veículo atualizado!");
      navigation.goBack();
    } catch {
      Alert.alert("Erro", "Falha ao salvar.");
    }
  }

  return (
    <ScrollView contentContainerStyle={{ padding: 20 }}>
      {Object.keys(form).map((field) =>
        field !== "veiculosId" ? (
          <TextInput
            key={field}
            value={String(form[field])}
            onChangeText={(v) => handle(field, v)}
            style={{
              borderWidth: 1,
              borderColor: "#ccc",
              padding: 12,
              borderRadius: 10,
              marginBottom: 12,
            }}
          />
        ) : null
      )}

      <TouchableOpacity
        style={{
          backgroundColor: "#FFC107",
          padding: 14,
          borderRadius: 12,
        }}
        onPress={salvar}
      >
        <Text style={{ textAlign: "center", color: "#000", fontSize: 18 }}>
          💾 Salvar Alterações
        </Text>
      </TouchableOpacity>
    </ScrollView>
  );
}
