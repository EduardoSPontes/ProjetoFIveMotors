import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  ScrollView,
  Image,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  Linking,
  Dimensions,
} from "react-native";
import axios from "axios";

const { width } = Dimensions.get("window");

export default function Home() {
  const [veiculos, setVeiculos] = useState([]);

  const parceirosData = [
    { nome: "Ford", logo: "https://upload.wikimedia.org/wikipedia/commons/3/3e/Ford_logo_flat.svg" },
    { nome: "Jeep", logo: require("../assets/parceiros/jeep-76 1.png") },
    { nome: "Nissan", logo: require("../assets/parceiros/nissan-logo-0-2 1.png") },
    { nome: "Chevrolet", logo: require("../assets/parceiros/Chevrolet_simple_logo 1.png") },
  ];

  useEffect(() => {
    const loadVeiculos = async () => {
      try {
        const response = await axios.get("http://localhost:5206/api/Veiculos");
        if (response.data) setVeiculos(response.data.slice(0, 3));
      } catch (error) {
        console.error(error);
      }
    };
    loadVeiculos();
  }, []);

  const renderVeiculo = ({ item }) => (
    <View style={styles.card}>
      <Image source={{ uri: item?.imagemsVeiculo?.[0] }} style={styles.destaqueImg} />
      <Text style={styles.cardTitle}>{item?.modelo}</Text>
      <Text style={styles.cardDesc}>{item?.descricao}</Text>
      
    </View>
  );

  const renderParceiro = ({ item }) => (
    <View style={styles.parceiroCard}>
      <Image source={item.logo} style={styles.parceiroLogo} />
      <Text style={styles.parceiroName}>{item.nome}</Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <ScrollView style={{ flex: 1 }}>
        {/* Hero */}
        <View style={styles.heroSection}>
          <Text style={styles.heroTitle}>
            Tecnologia que transforma a sua experiência de compra
          </Text>
          <Text style={styles.heroSubtitle}>
            Explore o futuro automotivo com a FiveMotors. Conecte-se com o carro ideal,
            descubra novas possibilidades e viva uma experiência totalmente digital.
          </Text>
          <Image
            source={{
              uri: "https://agencianovofoco.com.br/wp-content/uploads/2024/11/estrategias-de-marketing-digital-para-concessionarias.jpeg",
            }}
            style={styles.heroImg}
          />
          <TouchableOpacity style={styles.btnHighlight}>
            <Text style={styles.btnText}>Quero saber mais</Text>
          </TouchableOpacity>
        </View>

        {/* Destaques */}
        <View style={styles.destaquesSection}>
          <Text style={styles.sectionTitle}>Destaques da Semana</Text>
          <FlatList
            data={veiculos}
            renderItem={renderVeiculo}
            keyExtractor={(item) => item?.VeiculosId?.toString()}
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ paddingHorizontal: 10 }}
          />
        </View>

        {/* Parceiros */}
        <View style={styles.parceirosSection}>
          <Text style={styles.sectionTitle}>Empresas Parceiras</Text>
          <FlatList
            data={parceirosData}
            renderItem={renderParceiro}
            keyExtractor={(item) => item.nome}
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ paddingHorizontal: 10 }}
          />
        </View>

        {/* Footer */}
        <View style={styles.footer}>
          <View style={{ alignItems: "center", marginBottom: 15 }}>
            <Image source={require("../assets/logo/Logo.png")} style={{ width: 120, height: 40, marginBottom: 5, tintColor: "#fff" }} />
            <Text style={styles.footerText}>FiveMotors © 2025</Text>
            <Text style={styles.footerText}>Todos os direitos reservados.</Text>
          </View>
          <View style={{ alignItems: "center" }}>
            <Text style={styles.footerText}>Av. Automotiva, 500 - São Paulo, SP</Text>
            <Text style={styles.footerText}>contato@fivemotors.com</Text>
          </View>
          <Text style={[styles.footerText, { marginTop: 10, fontSize: 12 }]}>
            Desenvolvido por FiveMotors Dev Team
          </Text>
        </View>
      </ScrollView>

      {/* WhatsApp Fixo */}
      <TouchableOpacity
        style={styles.whatsappBtn}
        onPress={() => Linking.openURL("https://wa.me/5511999999999")}
      >
        <Text style={styles.whatsappText}>💬 Fale conosco</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#fff" },
  navbar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: 15,
    backgroundColor: "#fff",
    borderBottomWidth: 1,
    borderColor: "#ccc",
  },
  logo: { width: 70, height: 40, resizeMode: "contain" },
  navLinks: { flexDirection: "row", gap: 10 },
  navLink: { color: "#489891", fontWeight: "600", marginHorizontal: 5 },

  heroSection: { padding: 20, alignItems: "center" },
  heroTitle: { fontSize: 24, fontWeight: "bold", color: "#2B3A4B", marginBottom: 10, textAlign: "center" },
  heroSubtitle: { fontSize: 16, color: "#6C757D", marginBottom: 15, textAlign: "center" },
  heroImg: { width: width - 40, height: 200, borderRadius: 15, marginBottom: 15 },
  btnHighlight: { backgroundColor: "#0CDAC3", padding: 12, borderRadius: 25 },
  btnText: { color: "#fff", fontWeight: "600", textAlign: "center" },

  destaquesSection: { paddingVertical: 20 },
  sectionTitle: { fontSize: 20, fontWeight: "bold", color: "#2B3A4B", marginBottom: 10, textAlign: "center" },
  card: { backgroundColor: "#fff", borderRadius: 12, marginHorizontal: 10, width: width * 0.7, padding: 10, shadowColor: "#000", shadowOpacity: 0.1, shadowRadius: 5, elevation: 3 },
  destaqueImg: { width: "100%", height: 140, borderRadius: 12 },
  cardTitle: { fontWeight: "bold", fontSize: 16, marginTop: 10, color: "#2B3A4B" },
  cardDesc: { fontSize: 14, color: "#6C757D", marginBottom: 10 },
  btnDetalhes: { backgroundColor: "#489891", paddingVertical: 8, borderRadius: 20, alignItems: "center" },

  parceirosSection: { paddingVertical: 20, backgroundColor: "#F8F9FA" },
  parceiroCard: { backgroundColor: "#fff", padding: 12, borderRadius: 12, marginHorizontal: 10, alignItems: "center" },
  parceiroLogo: { width: 70, height: 40, resizeMode: "contain", marginBottom: 5 },
  parceiroName: { fontWeight: "600", color: "#2B3A4B" },

  footer: { backgroundColor: "#1f2a36", paddingVertical: 20, paddingHorizontal: 15 },
  footerText: { color: "#d1d1d1", textAlign: "center" },

  whatsappBtn: { position: "absolute", bottom: 20, right: 20, backgroundColor: "#25D366", padding: 12, borderRadius: 30 },
  whatsappText: { color: "#fff", fontWeight: "600" },
});
