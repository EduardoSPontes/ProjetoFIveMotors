import React, { useEffect, useState } from "react";
import { View, Text, TouchableOpacity, Alert } from "react-native";
import API from "../api/api";

export default function VeiculoDelete({ route, navigation }) {
  const { id } = route.params;
  const [veiculo, setVeiculo] = useState(null);

  useEffect(() => {
    API.get(`Veiculos/${id}`).then((res) => setVeiculo(res.data));
  }, []);

  async function deletar() {
    await API.delete(`Veiculos/${id}`);
    Alert.alert("Excluído!", "O veículo foi removido.");
    navigation.goBack();
  }

  if (!veiculo) return null;

  return (
    <View style={{ padding: 20 }}>
      <Text style={{ fontSize: 20, fontWeight: "bold", marginBottom: 10 }}>
        Tem certeza que deseja excluir?
      </Text>

      <Text>Marca: {veiculo.marca}</Text>
      <Text>Modelo: {veiculo.modelo}</Text>
      <Text>Ano: {veiculo.ano}</Text>

      <TouchableOpacity
        onPress={deletar}
        style={{
          backgroundColor: "#D32F2F",
          padding: 14,
          marginTop: 20,
          borderRadius: 12,
        }}
      >
        <Text style={{ textAlign: "center", color: "#fff" }}>🗑 Excluir</Text>
      </TouchableOpacity>

      <TouchableOpacity
        onPress={() => navigation.goBack()}
        style={{
          backgroundColor: "#999",
          padding: 14,
          marginTop: 10,
          borderRadius: 12,
        }}
      >
        <Text style={{ textAlign: "center", color: "#fff" }}>Cancelar</Text>
      </TouchableOpacity>
    </View>
  );
}
