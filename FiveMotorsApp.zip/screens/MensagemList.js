import React, { useEffect, useState } from "react";
import { View, Text, TouchableOpacity, FlatList } from "react-native";
import API from "../api/api";

export default function MensagensList({ navigation }) {
  const [msgs, setMsgs] = useState([]);

  useEffect(() => {
    API.get("FaleComVendedor").then((res) => setMsgs(res.data));
  }, []);

  return (
    <View style={{ padding: 16 }}>
      <FlatList
        data={msgs}
        keyExtractor={(item) => item.faleComVendedorId}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={{
              backgroundColor: "#fff",
              padding: 14,
              borderRadius: 12,
              elevation: 3,
              marginBottom: 12,
            }}
            onPress={() =>
              navigation.navigate("DetalhesMensagem", { id: item.faleComVendedorId })
            }
          >
            <Text style={{ fontSize: 18, fontWeight: "bold" }}>{item.nome}</Text>
            <Text>Email: {item.email}</Text>
            <Text>Telefone: {item.telefone}</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}
