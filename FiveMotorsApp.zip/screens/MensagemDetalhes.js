import React, { useEffect, useState } from "react";
import { View, Text, TouchableOpacity, Alert } from "react-native";
import API from "../api/api";

export default function MensagemDetalhes({ route, navigation }) {
  const { id } = route.params;
  const [msg, setMsg] = useState(null);

  useEffect(() => {
    API.get(`FaleComVendedor/${id}`).then((res) => setMsg(res.data));
  }, []);

  async function excluir() {
    await API.delete(`FaleComVendedor/${id}`);
    Alert.alert("Excluída!", "Mensagem removida.");
    navigation.goBack();
  }

  if (!msg) return null;

  return (
    <View style={{ padding: 20 }}>
      <Text style={{ fontSize: 22, fontWeight: "bold" }}>Mensagem</Text>

      <Text style={{ marginTop: 10 }}>Nome: {msg.nome}</Text>
      <Text>Email: {msg.email}</Text>
      <Text>Telefone: {msg.telefone}</Text>
      <Text>Assunto: {msg.assunto}</Text>

      <TouchableOpacity
        onPress={excluir}
        style={{
          backgroundColor: "#D32F2F",
          padding: 14,
          borderRadius: 12,
          marginTop: 20,
        }}
      >
        <Text style={{ textAlign: "center", color: "#fff" }}>Excluir</Text>
      </TouchableOpacity>
    </View>
  );
}
