import React, { useEffect, useState } from "react";
import { View, Text, FlatList, TouchableOpacity, ActivityIndicator } from "react-native";
import API from "../api/api";

export default function VeiculosList({ navigation }) {
  const [veiculos, setVeiculos] = useState([]);
  const [loading, setLoading] = useState(true);

  async function carregar() {
    try {
      const res = await API.get("Veiculos");
      setVeiculos(res.data);
    } catch (e) {
      console.log("Erro:", e);
    }
    setLoading(false);
  }

  useEffect(() => {
    const unsub = navigation.addListener("focus", carregar);
    return unsub;
  }, []);

  if (loading)
    return <ActivityIndicator size="large" style={{ marginTop: 50 }} />;

  return (
    <View style={{ flex: 1, padding: 16 }}>
      <TouchableOpacity
        style={{
          backgroundColor: "#1E88E5",
          padding: 14,
          borderRadius: 12,
          marginBottom: 16
        }}
        onPress={() => navigation.navigate("VeiculoCreate")}
      >
        <Text style={{ color: "#fff", textAlign: "center", fontWeight: "bold" }}>
          ➕ Criar Novo Veículo
        </Text>
      </TouchableOpacity>

      <FlatList
        data={veiculos}
        keyExtractor={(item) => item.veiculosId}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={{
              padding: 16,
              backgroundColor: "#FFF",
              marginBottom: 14,
              borderRadius: 12,
              elevation: 2,
            }}
            onPress={() => navigation.navigate("EditVeiculo", { id: item.veiculosId })}
          >
            <Text style={{ fontSize: 18, fontWeight: "bold" }}>
              {item.marca} {item.modelo}
            </Text>
            <Text style={{ opacity: 0.7 }}>Ano: {item.ano}</Text>
            <Text style={{ opacity: 0.7 }}>Preço: R$ {item.preco}</Text>

            <View style={{ flexDirection: "row", marginTop: 10, gap: 10 }}>
              <TouchableOpacity
                style={{
                  backgroundColor: "#FFC107",
                  padding: 10,
                  borderRadius: 8,
                  flex: 1,
                }}
                onPress={() => navigation.navigate("EditVeiculo", { id: item.veiculosId })}
              >
                <Text style={{ textAlign: "center" }}>✏ Editar</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={{
                  backgroundColor: "#D32F2F",
                  padding: 10,
                  borderRadius: 8,
                  flex: 1,
                }}
                onPress={() => navigation.navigate("DeleteVeiculo", { id: item.veiculosId })}
              >
                <Text style={{ textAlign: "center", color: "#fff" }}>🗑 Excluir</Text>
              </TouchableOpacity>
            </View>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}
