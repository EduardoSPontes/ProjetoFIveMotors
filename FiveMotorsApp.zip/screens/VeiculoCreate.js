import React, { useState } from "react";
import { View, Text, TextInput, TouchableOpacity, ScrollView, Alert } from "react-native";
import API from "../api/api";

export default function VeiculoCreate({ navigation }) {
  const [form, setForm] = useState({
    marca: "",
    modelo: "",
    ano: "",
    preco: "",
    descricao: "",
    estoque: "",
    imagemsVeiculo: ""
  });

  function handle(field, value) {
    setForm({ ...form, [field]: value });
  }

  async function salvar() {
    try {
      await API.post("Veiculos", form);
      Alert.alert("Sucesso", "Veículo cadastrado!");
      navigation.goBack();
    } catch (e) {
      Alert.alert("Erro", "Falha ao cadastrar veículo.");
    }
  }

  return (
    <ScrollView contentContainerStyle={{ padding: 20 }}>
      {Object.keys(form).map((field) => (
        <TextInput
          key={field}
          placeholder={field}
          value={form[field]}
          onChangeText={(v) => handle(field, v)}
          style={{
            borderWidth: 1,
            borderColor: "#ccc",
            padding: 12,
            borderRadius: 10,
            marginBottom: 12,
          }}
        />
      ))}

      <TouchableOpacity
        style={{
          backgroundColor: "#25D366",
          padding: 14,
          borderRadius: 12,
        }}
        onPress={salvar}
      >
        <Text style={{ textAlign: "center", color: "#fff", fontSize: 18 }}>
          💾 Salvar
        </Text>
      </TouchableOpacity>
    </ScrollView>
  );
}
