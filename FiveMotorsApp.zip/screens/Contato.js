import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { WebView } from 'react-native-webview';

// Tela "Contato" para React Native (único arquivo)
// Observações:
// 1) Requer instalação de react-native-webview: "npm install react-native-webview" (ou expo install react-native-webview)
// 2) Se preferir usar react-native-maps, substitua o WebView por MapView (requer configuração adicional).
// 3) Altere a URL de POST (API_URL) conforme seu backend (em produção não use localhost no dispositivo físico).

const API_URL = 'http://localhost:5206/api/FaleComVendedor'; // Use 10.0.2.2 para emulador Android, localhost não funciona em dispositivo físico
// Se você estiver em iOS simulator, pode usar http://localhost:5206

export default function ContatoScreen() {
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [telefone, setTelefone] = useState('');
  const [mensagem, setMensagem] = useState('');
  const [loading, setLoading] = useState(false);

  const validar = () => {
    if (!nome.trim()) return 'Preencha seu nome.';
    if (!email.trim()) return 'Preencha o email.';
    if (!telefone.trim()) return 'Preencha o telefone.';
    return null;
  };

  const enviar = async () => {
    const erro = validar();
    if (erro) return Alert.alert('Atenção', erro);

    const model = {
      Nome: nome,
      Email: email,
      Telefone: telefone,
      Assunto: mensagem,
    };

    try {
      setLoading(true);
      const res = await fetch(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(model),
      });

      if (res.ok) {
        Alert.alert('Sucesso', 'Mensagem enviada com sucesso!');
        // limpa campos
        setNome('');
        setEmail('');
        setTelefone('');
        setMensagem('');
      } else {
        const text = await res.text();
        console.warn('Erro resposta:', text);
        Alert.alert('Erro', 'Falha ao enviar mensagem. Tente novamente.');
      }
    } catch (e) {
      console.error(e);
      Alert.alert('Erro', 'Não foi possível conectar com o servidor. Verifique a URL e sua rede.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView contentContainerStyle={styles.container}>
        <View style={styles.header}>
          <Text style={styles.title}>👋 Fale com a FiveMotors</Text>
          <Text style={styles.subtitle}>
            Atendimento especializado para ajudar você a encontrar o carro ideal,
            esclarecer dúvidas ou agendar sua visita.
          </Text>
        </View>

        <View style={styles.cardRow}>
          <View style={styles.card}>
            <Text style={styles.cardTitle}>📝 Solicite Atendimento</Text>

            <TextInput
              style={styles.input}
              placeholder="Nome completo"
              value={nome}
              onChangeText={setNome}
              returnKeyType="next"
            />

            <TextInput
              style={styles.input}
              placeholder="Email"
              keyboardType="email-address"
              value={email}
              onChangeText={setEmail}
            />

            <TextInput
              style={styles.input}
              placeholder="Telefone"
              keyboardType="phone-pad"
              value={telefone}
              onChangeText={setTelefone}
            />

            <TextInput
              style={[styles.input, styles.textarea]}
              placeholder="Mensagem"
              multiline
              numberOfLines={6}
              value={mensagem}
              onChangeText={setMensagem}
            />

            <View style={styles.buttonsRow}>
              <TouchableOpacity
                style={styles.sendButton}
                onPress={enviar}
                disabled={loading}
              >
                {loading ? (
                  <ActivityIndicator />
                ) : (
                  <Text style={styles.sendButtonText}>Enviar Mensagem</Text>
                )}
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.clearButton}
                onPress={() => {
                  setNome('');
                  setEmail('');
                  setTelefone('');
                  setMensagem('');
                }}
                disabled={loading}
              >
                <Text style={styles.clearButtonText}>Limpar</Text>
              </TouchableOpacity>
            </View>
          </View>

          <View style={styles.card}>
            <Text style={[styles.cardTitle, { textAlign: 'center' }]}>📍 Localização & Atendimento</Text>

            <View style={styles.mapContainer}>
                {Platform.OS === "web" ? (
        // 👍 Web usa iframe direto
        <iframe
          src="https://www.google.com/maps/embed?pb=!1m18..."
          style={{
            width: "100%",
            height: "100%",
            border: 0,
            borderRadius: 12,
          }}
          loading="lazy"
          allowFullScreen
        ></iframe>
      ) : (
        // 📱 Mobile usa WebView
        <WebView
          source={{
            html: `<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0">
            <iframe 
              src="https://www.google.com/maps/embed?pb=!1m18..." 
              width="100%" height="100%" style="border:0;" 
              allowfullscreen="" loading="lazy">
            </iframe>`,
          }}
          style={{ flex: 1, borderRadius: 12 }}
        />
      )}
            </View>

            <View style={styles.locationBox}>
              <Text style={styles.unitTitle}>FiveMotors — Unidade São Paulo</Text>
              <Text style={styles.address}>Rua Exemplo, 123 · São Paulo — SP</Text>

              <View style={styles.openBox}>
                <Text style={styles.openText}>⏰ Atendimento: 08h às 19h (Seg–Sáb)</Text>
              </View>
            </View>
          </View>
        </View>

      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#F6F7F9',
  },
  header: {
    alignItems: 'center',
    marginBottom: 18,
  },
  title: {
    color: '#1F2F3E',
    fontSize: 26,
    fontWeight: '800',
    textAlign: 'center',
  },
  subtitle: {
    color: '#6C757D',
    fontSize: 14,
    maxWidth: 680,
    textAlign: 'center',
    marginTop: 8,
  },
  cardRow: {
    // em dispositivos menores, cards empilham; em tablets podem ficar lado a lado
    flexDirection: 'column',
  },
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 16,
    marginBottom: 16,
    // sombra básica
    shadowColor: '#000',
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 3,
  },
  cardTitle: {
    fontWeight: '700',
    color: '#1F2F3E',
    fontSize: 18,
    marginBottom: 12,
  },
  input: {
    backgroundColor: '#F8FAFB',
    borderRadius: 12,
    padding: 12,
    marginBottom: 10,
  },
  textarea: {
    height: 120,
    textAlignVertical: 'top',
  },
  buttonsRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 8,
  },
  sendButton: {
    backgroundColor: '#0AADA6',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 14,
    marginRight: 10,
  },
  sendButtonText: {
    color: '#fff',
    fontWeight: '700',
  },
  clearButton: {
    backgroundColor: '#D9534F',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 14,
  },
  clearButtonText: {
    color: '#fff',
    fontWeight: '600',
  },
  mapContainer: {
    height: 220,
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 12,
  },
  locationBox: {
    alignItems: 'center',
  },
  unitTitle: {
    fontWeight: '700',
    color: '#1F2F3E',
  },
  address: {
    color: '#6C757D',
    marginTop: 6,
  },
  openBox: {
    backgroundColor: '#F9FAFB',
    padding: 10,
    borderRadius: 12,
    marginTop: 10,
  },
  openText: {
    fontWeight: '600',
    color: '#1F2F3E',
  },
});
